# Ansible Galaxy Collection: ghhalba.sample_ansible_collection

This is a sample collection demonstrating the structure of an Ansible Galaxy collection.

## Roles

- `test_role`: A sample role.

## Modules

- `sample_module`: A sample custom module.

## Usage

To use this collection, install it with the following command:

```bash
ansible-galaxy collection install ghhalba.sample_ansible_collection

